<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\AuditRequest;
use App\Models\ChatMessage;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

final class SiteAndApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_all_seven_pages_render(): void
    {
        $pages = [
            '/' => 'Remote HR solutions',
            '/what-we-are' => 'Empower people. Simplify work. Build momentum.',
            '/what-we-do' => 'Fourteen services',
            '/pricing' => 'PKR 40,000',
            '/student-hub' => 'Mock interview simulator',
            '/faq' => 'The questions clients and students actually ask',
            '/free-hr-audit' => 'Tell us where HR hurts',
        ];

        foreach ($pages as $path => $needle) {
            $response = $this->get($path);
            $response->assertOk();
            $response->assertSee($needle, false);
        }
    }

    public function test_pricing_page_marks_unresolved_inclusions_as_pending(): void
    {
        $this->get('/pricing')
            ->assertOk()
            ->assertSee('PKR 75,000')
            ->assertSee('Pending Input')
            ->assertDontSee('most popular', false);
    }

    public function test_faq_page_lists_all_verified_answers(): void
    {
        $total = collect(config('emplowise.faqs'))->sum(fn (array $group): int => count($group['items']));

        $this->get('/faq')
            ->assertOk()
            ->assertSee($total.' questions')
            ->assertSee('Yes. All five tools are free, with no account required.');
    }

    public function test_audit_submission_is_validated_and_stored(): void
    {
        $this->postJson('/api/audit', [])->assertStatus(422);

        $payload = [
            'contact_name' => 'Test Founder',
            'company_name' => 'Acme Labs',
            'email' => 'Founder@AcmeLabs.pk',
            'phone' => '+92 300 1234567',
            'headcount_band' => '11-20',
            'pain_points' => ['payroll', 'policy'],
            'notes' => 'Payroll runs on a spreadsheet.',
            'preferred_date' => now()->addDays(5)->toDateString(),
            'preferred_slot' => 'Morning (9:00 to 12:00)',
            'consent' => '1',
        ];

        $response = $this->postJson('/api/audit', $payload)->assertStatus(201);

        $reference = $response->json('reference');
        $this->assertStringStartsWith('EMP-', $reference);

        $this->assertDatabaseHas('audit_requests', [
            'reference' => $reference,
            'email' => 'founder@acmelabs.pk',
            'headcount_band' => '11-20',
            'status' => 'new',
        ]);

        $audit = AuditRequest::query()->where('reference', $reference)->firstOrFail();
        $this->assertSame(['payroll', 'policy'], $audit->pain_points);
    }

    public function test_audit_honeypot_is_silently_accepted_without_storing(): void
    {
        $this->postJson('/api/audit', ['website' => 'spam.example'])->assertStatus(202);

        $this->assertDatabaseCount('audit_requests', 0);
    }

    public function test_chat_returns_a_grounded_fallback_reply_and_logs_the_turn(): void
    {
        config(['ai.alibaba.api_key' => null]);

        $response = $this->postJson('/api/chat', [
            'message' => 'What do the packages cost?',
            'history' => [],
        ]);

        $response->assertOk()
            ->assertJsonStructure(['session_id', 'reply', 'intent', 'model', 'source'])
            ->assertJsonPath('intent', 'pricing')
            ->assertJsonPath('source', 'fallback');

        $this->assertStringContainsString('PKR 40,000', (string) $response->json('reply'));
        $this->assertDatabaseCount('chat_messages', 2);
        $this->assertSame(2, ChatMessage::query()->count());
    }

    public function test_interview_questions_come_from_the_local_bank_without_an_api_key(): void
    {
        config(['ai.alibaba.api_key' => null]);

        $this->postJson('/api/student/interview/questions', [
            'role' => 'Data and Analytics',
            'level' => 'Entry level',
        ])->assertOk()
            ->assertJsonCount(3, 'questions')
            ->assertJsonPath('source', 'local');
    }

    public function test_interview_feedback_is_deterministic_and_bounded(): void
    {
        config(['ai.alibaba.api_key' => null]);

        $payload = [
            'role' => 'Data and Analytics',
            'level' => 'Entry level',
            'question' => 'Describe a dataset you cleaned. What was messy?',
            'answer' => 'At my university lab we had a survey dataset with duplicate rows and missing income values. I removed duplicates, standardised city names, and filled missing values with the median. As a result the analysis error dropped and the team could trust the report.',
        ];

        $first = $this->postJson('/api/student/interview/feedback', $payload)->assertOk();
        $second = $this->postJson('/api/student/interview/feedback', $payload)->assertOk();

        $this->assertSame($first->json('score'), $second->json('score'));
        $this->assertGreaterThanOrEqual(0, $first->json('score'));
        $this->assertLessThanOrEqual(100, $first->json('score'));
        $first->assertJsonStructure(['score', 'verdict', 'strengths', 'fixes', 'model_answer', 'source']);
    }

    public function test_ats_score_is_explainable_and_bounded(): void
    {
        config(['ai.alibaba.api_key' => null]);

        $resume = <<<'RESUME'
Ayesha Khan
Karachi, Pakistan | ayesha@example.com | +92 300 1234567 | linkedin.com/in/ayesha

Summary
Data analyst with experience in SQL, Excel, and Python dashboards.

Experience
Data Analyst Intern — Northline
- Built SQL reports for 3 teams and reduced manual reporting time by 6 hours a week.
- Cleaned a 40,000 row dataset and documented the data dictionary.
- Presented weekly findings to two product managers.

Education
BS Computer Science — IBA Karachi, 2022 to 2026

Skills
SQL, Python, Excel, Power BI, stakeholder communication, data cleaning
RESUME;

        $jd = 'We are hiring a data analyst. Requirements include strong SQL, Python, Excel, Power BI, dashboarding, data cleaning, stakeholder communication, and reporting. You will build dashboards, analyse product metrics, and present insights to business teams.';

        $response = $this->postJson('/api/student/ats', [
            'resume' => $resume,
            'job_description' => $jd,
        ])->assertOk();

        $response->assertJsonStructure([
            'score', 'verdict', 'breakdown', 'matched', 'missing', 'structure', 'format', 'fixes', 'source',
        ]);

        $score = $response->json('score');
        $this->assertGreaterThanOrEqual(3, $score);
        $this->assertLessThanOrEqual(98, $score);
        $this->assertCount(3, $response->json('breakdown'));
        $this->assertSame(55 + 25 + 20, collect($response->json('breakdown'))->sum('max'));
        $this->assertSame('local', $response->json('source'));
    }

    public function test_profile_optimizer_rejects_empty_input_and_rewrites_weak_copy(): void
    {
        config(['ai.alibaba.api_key' => null]);

        $this->postJson('/api/student/profile', [])->assertStatus(422);

        $response = $this->postJson('/api/student/profile', [
            'headline' => 'Final year CS student passionate about data',
            'summary' => 'I am a hardworking student looking for internship opportunities in data analytics.',
            'bullets' => 'Worked on a dashboard project'."\n".'Responsible for cleaning survey data',
        ])->assertOk();

        $response->assertJsonCount(3, 'headlines');
        $this->assertStringNotContainsString('passionate', strtolower((string) $response->json('headlines.0')));
        $this->assertStringContainsString('[add one number]', implode(' ', $response->json('bullets')));
        $response->assertJsonPath('source', 'local');
    }
}
